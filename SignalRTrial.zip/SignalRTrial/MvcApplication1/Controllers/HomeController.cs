﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.SignalR;
using MvcApplication1.Hubs;

namespace MvcApplication1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";
            //SendMessage("Index action invoked.");
            SendMessage((string)Session["_SessionConn"]+"Index");
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";
            //SendMessage("About action invoked.");
            SendMessage((string)Session["_SessionConn"] + "About");
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            //SendMessage("Contact action invoked.");
            SendMessage((string)Session["_SessionConn"] + "Contact");

            return View();
        }

        private void SendMessage(string message)
        {
            GlobalHost.ConnectionManager.GetHubContext<NotificationHub>().Clients.Client((string)Session["_SessionConn"]).sendMessage(message);
        }
    }
}
