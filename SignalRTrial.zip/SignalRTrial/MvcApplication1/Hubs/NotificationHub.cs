﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using System.Web.Mvc;

namespace MvcApplication1.Hubs
{
    public class NotificationHub : Hub
    {
        public void Activate(string name, string connID)
        {
            //return "Monitor Activated";
            Clients.Client(connID).notifyUsers(name+connID);
            setCon(connID);
        }

        public void setCon(string ID)
        {
            GlobalCon.IniCon = ID;
        }
    }
}